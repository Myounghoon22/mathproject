from django.http import HttpResponse
from django.core.handlers.wsgi import WSGIRequest
from django.views.decorators.csrf import csrf_exempt
from django.core.exceptions import BadRequest


def index(request):
    # Table 생성 코드 수정 (javascript로 하면 더 깔끔할 듯?)
    table = '<td width="80" height="80"><input name="" type="number" min="1" max="9"></td>'
    table *= 3
    table = '<tr>' + table + '</tr>'
    table *= 3
    table = '<td><table class="inner-table"><tbody>' + table + '</tbody></table></td>'
    table *= 3
    table = '<tr>' + table + '</tr>'
    table *= 3
    table = '<tbody>' + table + '</tbody>'
    
    # 앞에서부터 name 속성 부여
    for i in range(81):
        table = table.replace('name=""', f'name="{i}"', 1)
    
    return HttpResponse(HtmlTemplete(table))


@csrf_exempt
def HtmlTemplete(table):
    # CSS 파일로 옮길 수 있도록 style 분리
    style = '''
    .inner-table {
        border: 2;
        align: center;
        cellspacing: 0;
        bordercolor: black;
        width: 240;
        height: 240
    }

    table, th, td {
        border-collapse: collapse;
    }

    input {
        width:80px;height:80px;font-size:30px;dispaly:block;text-align:center;margin:0 auto;
    }

    /* input number 화살표 제거 */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button
    {
        -webkit-appearance: none;
        margin: 0;
    }
    input[type=number] {
        -moz-appearance: textfield;
    }
    '''

    templete=f'''    
        <html>
            <head>
                <style>
                    {style}
                </style>
            </head>
            <body>
                <form action='/solving' method='post'>
                    <div style='display:block;'>
                        <table border="5" bordercolor="black" width="240" height="240">
                            {table}
                        </table>
                        <div style='margin-left:355px; margin-top:50px;'>
                            <input type="submit" style="width:80px; height:80px;">
                        </div>
                    </div>  
                </form>
            </body>
        </html>
    '''
    return HttpResponse(templete)


@csrf_exempt
def solve(request: WSGIRequest):
    list = []
    candidates_list = [None] * 81 # 후보 리스트
    if request.method=='POST':
        # 리스트에 숫자 추가 (빈 칸이면 None)
        for key, value in request.POST.items():
            try:
                list.append(int(value))
            except ValueError:
                list.append(None)
        
        updated = True
        while updated:
            
            updated = False
            # 후보 리스트 업데이트
            for i in range(81):
                x, y = idx_to_coords(i)
                if list[i] != None:
                    candidates_list[i] = None
                else:
                    candidates = [j for j in range(1, 10)]
                    for j in range(9):
                        # 사각형에서 중복되는 숫자 제거
                        try:
                            candidates.remove(list[i//9*9+j])
                        except ValueError:
                            pass
                    for j in range(9):
                        # 행에서 중복되는 숫자 제거
                        try:
                            candidates.remove(list[coords_to_idx(j, y)])
                        except ValueError:
                            pass
                    for j in range(9):
                        # 열에서 중복되는 숫자 제거
                        try:
                            candidates.remove(list[coords_to_idx(x, j)])
                        except ValueError:
                            pass

                    if len(candidates) == 0:
                        raise BadRequest
                    elif len(candidates) == 1:
                        list[i] = candidates[0]
                        candidates_list[i] = None
                        updated = True
                    else:
                        candidates_list[i] = candidates  # type: ignore

            for n in range(1, 10):
                for i in range(9):
                    # i째 가로줄, 세로줄, 작은 박스 안에 1개만 있는 숫자 확인
                    # 가로줄
                    candidates = [j for j in range(9)]
                    for j in range(9):
                        idx = coords_to_idx(i, j)
                        if candidates_list[idx] == None:
                            if list[idx] == n:
                                break
                            continue
                        elif n in candidates_list[idx]:  # type: ignore
                            candidates.remove(j)
                    if len(candidates) == 1:
                        list[coords_to_idx(i, candidates[0])] = n
                        updated = True

                    # 세로줄
                    candidates = [j for j in range(9)]
                    for j in range(9):
                        idx = coords_to_idx(j, i)
                        if candidates_list[idx] == None:
                            if list[idx] == n:
                                break
                            continue
                        elif n in candidates_list[idx]:  # type: ignore
                            candidates.remove(j)
                    if len(candidates) == 1:
                        list[coords_to_idx(candidates[0], i)] = n
                        updated = True

                    # 작은 박스
                    candidates = [j for j in range(9)]
                    for j in range(9):
                        idx = i * 9 + j
                        if candidates_list[idx] == None:
                            if list[idx] == n:
                                break
                            continue
                        elif n in candidates_list[idx]:  # type: ignore
                            candidates.remove(j)
                    if len(candidates) == 1:
                        list[i * 9 + candidates[0]] = n
                        updated = True

        
        """ # 프로세스 종료 후 빈 칸이 남았다면 에러
        if None in list:
            raise ValueError("Sudoku unsolved.") """

        return HttpResponse(str(list))
    
    # Post가 아닐 때 에러
    raise BadRequest


def idx_to_coords(idx:int):
    x = (idx % 9) % 3 + (idx // 9) % 3 * 3
    y = (idx % 9) // 3 + (idx // 9) // 3 * 3
    return x, y


def coords_to_idx(x:int, y:int):
    return x%3 + y%3*3 + x//3*9 + y//3*27
