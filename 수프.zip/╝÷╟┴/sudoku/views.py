from msilib.schema import tables
from django.http import HttpResponse
from django.shortcuts import render

kans= []


def index(request):
    table=''
    for i in range(1,10,1):
        if i==1:
            table += f'''
            <tr>
                <td>
                    <table border="2" align="center" cellspacing="0" bordercolor="black" width="240" height="240">
                        <tr>
                            <td width="80" height="80"><input type="text" name=str({i})style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+1)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+2)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        </tr>
                        <tr>
                            <td width="80" height="80"><input type="text" name=str({i}+3)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+4)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+5)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        </tr>
                        <tr>
                            <td width="80" height="80"><input type="text" name=str({i}+6)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+7)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+8)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        </tr>
                    </table>
                </td>
            </tr>'''
        elif i%3!=0:
            table += f'''
            <td>
                <table border="2" align="center" cellspacing="0" bordercolor="black" width="240" height="240">
                    <tr>
                        <td width="80" height="80"><input type="text" name=str({i})style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        <td width="80" height="80"><input type="text" name=str({i}+1)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        <td width="80" height="80"><input type="text" name=str({i}+2)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                    </tr>
                    <tr>
                        <td width="80" height="80"><input type="text" name=str({i}+3)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        <td width="80" height="80"><input type="text" name=str({i}+4)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        <td width="80" height="80"><input type="text" name=str({i}+5)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                    </tr>
                    <tr>
                        <td width="80" height="80"><input type="text" name=str({i}+6)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        <td width="80" height="80"><input type="text" name=str({i}+7)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        <td width="80" height="80"><input type="text" name=str({i}+8)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                    </tr>
                </table>
            </td>'''
        else:
            table += f'''
            <tr>
                <td>
                    <table border="2" align="center" cellspacing="0" bordercolor="black" width="240" height="240">
                        <tr>
                            <td width="80" height="80"><input type="text" name=str({i})style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+1)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+2)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        </tr>
                        <tr>
                            <td width="80" height="80"><input type="text" name=str({i}+3)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+4)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+5)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        </tr>
                        <tr>
                            <td width="80" height="80"><input type="text" name=str({i}+6)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+7)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                            <td width="80" height="80"><input type="text" name=str({i}+8)style="width:100%;height:100%;font-size:30px;dispaly:block;text-align:center;margin:0 auto;"></td>
                        </tr>
                    </table>
                </td>
            </tr>'''
            

    return HttpResponse(f'''
    <html>
        <head>
        </head>
        <body>
            <div style='display:block'>
                <table border="5" bordercolor="black" width="240" height="240">
                            {table} 
                </table>
            </div>
        </body>
    </html>
''')
